﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Hisco_Population_Test.Models;
using Newtonsoft.Json;

namespace Hisco_Population_Test.Controllers
{
    public class PopulationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult LoadPopulationData()
        {
            List<Population> populations = new List<Population>();
            //Read the contents of CSV file.
            string csvData = System.IO.File.ReadAllText("Data/PopulationSampleDataSet.csv");

            //Execute a loop over the rows.

            for (int i = 1; i < csvData.Split('\n').Length; i++)
            {
                if (!string.IsNullOrEmpty(csvData.Split('\n')[i]))
                {
                    populations.Add(new Population
                    {
                        ID = Convert.ToInt32(csvData.Split('\n')[i].Split(',')[0]),
                        Country = csvData.Split('\n')[i].Split(',')[1],
                        Year = csvData.Split('\n')[i].Split(',')[2],
                        TotalMale = csvData.Split('\n')[i].Split(',')[3],
                        TotalFemale = csvData.Split('\n')[i].Split(',')[4]
                    });
                }
            }
            //return View(populations);
            return Json(JsonConvert.SerializeObject(populations));
        }
    }
}