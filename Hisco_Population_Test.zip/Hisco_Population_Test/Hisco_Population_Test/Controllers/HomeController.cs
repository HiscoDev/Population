﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Hisco_Population_Test.Models;
using Newtonsoft.Json;
using System.IO;

namespace Hisco_Population_Test.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            List<Population> populations = new List<Population>();
            //Read the contents of CSV file.
            string csvData = System.IO.File.ReadAllText("Data/PopulationSampleDataSet.csv");

            //Execute a loop over the rows.

            for (int i = 1; i < csvData.Split('\n').Length; i++)
            {
                if (!string.IsNullOrEmpty(csvData.Split('\n')[i]))
                {
                    populations.Add(new Population
                    {
                        ID = Convert.ToInt32(csvData.Split('\n')[i].Split(',')[0]),
                        Country = csvData.Split('\n')[i].Split(',')[1],
                        Year = csvData.Split('\n')[i].Split(',')[2],
                        TotalMale = csvData.Split('\n')[i].Split(',')[3],
                        TotalFemale = csvData.Split('\n')[i].Split(',')[4]
                    });
                }
            }
            return View(populations);
            //return Json(JsonConvert.SerializeObject(populations));
            //return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Population populations = new Population();
            string csvData = System.IO.File.ReadAllText("Data/PopulationSampleDataSet.csv");
            //Execute a loop over the rows.
            for (int i = 1; i < csvData.Split('\n').Length; i++)
            {
                if (!string.IsNullOrEmpty(csvData.Split('\n')[i]))
                {
                    if (Convert.ToInt32(csvData.Split('\n')[i].Split(',')[0]) == id)
                    {
                        populations.ID = Convert.ToInt32(csvData.Split('\n')[i].Split(',')[0]);
                        populations.Country = csvData.Split('\n')[i].Split(',')[1];
                        populations.Year = csvData.Split('\n')[i].Split(',')[2];
                        populations.TotalMale = csvData.Split('\n')[i].Split(',')[3];
                        populations.TotalFemale = csvData.Split('\n')[i].Split(',')[4];
                    }
                }
            }
            return View(populations);
        }

        [HttpPost]
        public IActionResult UpdatePopulation(Population population)
        {
            if (ModelState.IsValid)
            {
                List<String> lines = new List<String>();
                using (StreamReader reader = new StreamReader(System.IO.File.OpenRead(@"Data/PopulationSampleDataSet.csv")))
                {
                    String line;
                    int i = 0;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.Contains(","))
                        {
                            String[] split = line.Split(',');
                            if (i != 0)
                            {
                                if (Convert.ToInt32(split[0]) == population.ID)
                                {
                                    // update that 
                                    split[1] = population.Country;
                                    split[2] = population.Year;
                                    split[3] = population.TotalMale.ToString();
                                    split[4] = population.TotalFemale.ToString();
                                    line = String.Join(",", split);
                                    lines.Add(line);
                                }
                                else
                                {
                                    split[1] = split[1];
                                    split[2] = split[2];
                                    split[3] = split[3];
                                    split[4] = split[4];
                                    line = String.Join(",", split);
                                    lines.Add(line);
                                }
                            }
                            else
                            {
                                split[0] = "ID";
                                split[1] = "Country";
                                split[2] = "Year";
                                split[3] = "TotalMale";
                                split[4] = "TotalFemale";
                                line = String.Join(",", split);
                                lines.Add(line);
                                i++;
                            }
                        }
                    }
                }

                using (StreamWriter writer = new StreamWriter(@"Data/PopulationSampleDataSet.csv", false))
                {
                    foreach (String line in lines)
                    {
                        writer.WriteLine(line);
                    }
                }
            }
            return RedirectToAction("Index", "Home");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
