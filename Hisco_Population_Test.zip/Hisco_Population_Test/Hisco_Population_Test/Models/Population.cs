﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Hisco_Population_Test.Models
{
    public class Population
    {
        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "Please enter country")]
        [Display(Name = "Country")]
        public string Country { get; set; }
        [Required(ErrorMessage = "Please enter Year")]
        [Display(Name = "Year")]
        public string Year { get; set; }
        [Required(ErrorMessage = "Please enter Total Male")]
        [Display(Name = "Total Male")]
        public string TotalMale { get; set; }
        [Required(ErrorMessage = "Please enter Total Female")]
        [Display(Name = "Total Female")]
        public string TotalFemale { get; set; }
    }
}
