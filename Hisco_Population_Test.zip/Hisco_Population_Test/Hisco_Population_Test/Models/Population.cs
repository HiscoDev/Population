﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hisco_Population_Test.Models
{
    public class Population
    {
        public int ID { get; set; }
        public string Country { get; set; }
        public string Year { get; set; }
        public string TotalMale { get; set; }
        public string TotalFemale { get; set; }
    }
}
